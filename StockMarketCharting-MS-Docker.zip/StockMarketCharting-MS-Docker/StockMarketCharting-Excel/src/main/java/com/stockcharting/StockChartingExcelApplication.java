package com.stockcharting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StockChartingExcelApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockChartingExcelApplication.class, args);
	}

}
